view 기준으로 작성되었던 homeggu 프로젝트 외에
기능 구현 위주로 작성하고 있는 springboard6 입니다.
